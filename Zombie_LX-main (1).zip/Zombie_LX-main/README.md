**Introduction**

"Apocalypse Dawn - Survive the Undead" adalah game zombie survival yang dimana game tersebut menantang pemain untuk menjelajahi dunia game yang dikuasai zombie. 
Game "Apocalypse Dawn - Survive the Undead"  menawarkan perpaduan genre game yaitu antara action, casual, dan RPG elements to untuk memberikan pengalaman 2D survival

Assets:
can be seen at folder dist->assets

## How to Run: 
    - open **CMD** on the root folder of Zombie_LX
    - type "gulp"
