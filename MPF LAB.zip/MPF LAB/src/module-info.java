module mpflab {
	opens main;
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.media;
}